﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ChatbotPart3
{
    public partial class CyberChatForm : Form
    {
        private List<string> activityLog = new List<string>();
        private List<TaskItem> tasks = new List<TaskItem>();
        private int quizScore = 0;
        private int currentQuizIndex = 0;

        private List<QuizQuestion> quizQuestions = new List<QuizQuestion>
        {
            new QuizQuestion("What should you do if you receive a suspicious email?", new string[] { "Reply", "Report as phishing", "Ignore", "Click the link" }, 1),
            new QuizQuestion("True or False: 123456 is a strong password.", new string[] { "True", "False" }, 1),
            new QuizQuestion("Which of the following is a good password?", new string[] { "John1990", "P@ssw0rd!", "Hello123", "qwerty" }, 1),
            new QuizQuestion("What is 2FA?", new string[] { "A virus", "A firewall", "Two-factor authentication", "None" }, 2),
            new QuizQuestion("True or False: Never update your software.", new string[] { "True", "False" }, 1),
            new QuizQuestion("Which is a phishing sign?", new string[] { "Strange email domain", "Personal greeting", "Known sender", "Clear formatting" }, 0),
            new QuizQuestion("What data should you never share online?", new string[] { "Your favorite food", "Your pet's name", "Your bank PIN", "Your birth year" }, 2),
            new QuizQuestion("What helps protect your online accounts?", new string[] { "2FA", "Weak passwords", "Public Wi-Fi", "Ignoring updates" }, 0),
            new QuizQuestion("True or False: You should use the same password for all sites.", new string[] { "True", "False" }, 1),
            new QuizQuestion("What does a firewall do?", new string[] { "Cooks your data", "Protects against threats", "Stores passwords", "Slows down the computer" }, 1)
        };

        public CyberChatForm()
        {
           
            InitUI();
        }

        private void InitUI()
        {
            this.Text = "Cybersecurity Chatbot";
            this.Size = new Size(800, 600);

            TabControl tabControl = new TabControl();
            tabControl.Dock = DockStyle.Fill;
            TabPage chatTab = new TabPage("Chatbot");
            TabPage taskTab = new TabPage("Tasks");
            TabPage quizTab = new TabPage("Quiz");
            TabPage logTab = new TabPage("Activity Log");

            tabControl.TabPages.Add(chatTab);
            tabControl.TabPages.Add(taskTab);
            tabControl.TabPages.Add(quizTab);
            tabControl.TabPages.Add(logTab);

            this.Controls.Add(tabControl);

            // Chat Tab
            RichTextBox chatHistory = new RichTextBox();
            chatHistory.Dock = DockStyle.Top;
            chatHistory.Height = 300;
            chatHistory.ReadOnly = true;
            TextBox chatInput = new TextBox();
            chatInput.Dock = DockStyle.Top;
            chatInput.Text = "Type your message here...";
            chatInput.ForeColor = SystemColors.GrayText;
            chatInput.GotFocus += (s, e) =>
            {
                if (chatInput.Text == "Type your message here...")
                {
                    chatInput.Text = "";
                    chatInput.ForeColor = SystemColors.WindowText;
                }
            };
            chatInput.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(chatInput.Text))
                {
                    chatInput.Text = "Type your message here...";
                    chatInput.ForeColor = SystemColors.GrayText;
                }
            };

            Button chatSend = new Button();
            chatSend.Text = "Send";
            chatSend.Dock = DockStyle.Top;

            chatSend.Click += (s, e) =>
            {
                if (chatInput.Text != "Type your message here..." && !string.IsNullOrWhiteSpace(chatInput.Text))
                {
                    string input = chatInput.Text.ToLower();
                    chatHistory.AppendText("You: " + input + "\n");

                    string response = ChatBotLogic.GetResponse(input);
                    chatHistory.AppendText("Bot: " + response + "\n\n");
                    activityLog.Add("[Chat] User said: " + input);
                    chatInput.Text = "";
                }
            };

            chatTab.Controls.Add(chatHistory);
            chatTab.Controls.Add(chatInput);
            chatTab.Controls.Add(chatSend);

            // Task Tab
            ListBox taskList = new ListBox();
            taskList.Dock = DockStyle.Top;
            taskList.Height = 300;
            TextBox taskTitle = new TextBox();
            taskTitle.Dock = DockStyle.Top;
            taskTitle.Text = "Task Title";
            taskTitle.ForeColor = SystemColors.GrayText;
            taskTitle.GotFocus += (s, e) =>
            {
                if (taskTitle.Text == "Task Title")
                {
                    taskTitle.Text = "";
                    taskTitle.ForeColor = SystemColors.WindowText;
                }
            };
            taskTitle.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(taskTitle.Text))
                {
                    taskTitle.Text = "Task Title";
                    taskTitle.ForeColor = SystemColors.GrayText;
                }
            };

            TextBox taskDesc = new TextBox();
            taskDesc.Dock = DockStyle.Top;
            taskDesc.Text = "Task Description";
            taskDesc.ForeColor = SystemColors.GrayText;
            taskDesc.GotFocus += (s, e) =>
            {
                if (taskDesc.Text == "Task Description")
                {
                    taskDesc.Text = "";
                    taskDesc.ForeColor = SystemColors.WindowText;
                }
            };
            taskDesc.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(taskDesc.Text))
                {
                    taskDesc.Text = "Task Description";
                    taskDesc.ForeColor = SystemColors.GrayText;
                }
            };

            DateTimePicker reminderPicker = new DateTimePicker();
            reminderPicker.Dock = DockStyle.Top;
            Button addTaskBtn = new Button();
            addTaskBtn.Text = "Add Task";
            addTaskBtn.Dock = DockStyle.Top;

            addTaskBtn.Click += (s, e) =>
            {
                if (taskTitle.Text != "Task Title" && !string.IsNullOrWhiteSpace(taskTitle.Text))
                {
                    TaskItem task = new TaskItem(
                        taskTitle.Text == "Task Title" ? "" : taskTitle.Text,
                        taskDesc.Text == "Task Description" ? "" : taskDesc.Text,
                        reminderPicker.Value);
                    tasks.Add(task);
                    taskList.Items.Add(task.ToString());
                    activityLog.Add("[Task] Added: " + task.Title + ", Reminder: " + task.Reminder.ToShortDateString());

                    taskTitle.Text = "Task Title";
                    taskTitle.ForeColor = SystemColors.GrayText;
                    taskDesc.Text = "Task Description";
                    taskDesc.ForeColor = SystemColors.GrayText;
                }
            };

            taskTab.Controls.Add(taskList);
            taskTab.Controls.Add(taskTitle);
            taskTab.Controls.Add(taskDesc);
            taskTab.Controls.Add(reminderPicker);
            taskTab.Controls.Add(addTaskBtn);

            // Quiz Tab
            Label questionLabel = new Label();
            questionLabel.Text = "Question";
            questionLabel.Dock = DockStyle.Top;
            questionLabel.Height = 60;
            FlowLayoutPanel answerPanel = new FlowLayoutPanel();
            answerPanel.Dock = DockStyle.Top;
            answerPanel.Height = 200;
            Button submitAnswerBtn = new Button();
            submitAnswerBtn.Text = "Submit Answer";
            submitAnswerBtn.Dock = DockStyle.Top;
            Label feedbackLabel = new Label();
            feedbackLabel.Dock = DockStyle.Top;
            feedbackLabel.Height = 60;

            Action LoadQuizQuestion = () =>
            {
                answerPanel.Controls.Clear();
                if (currentQuizIndex < quizQuestions.Count)
                {
                    QuizQuestion q = quizQuestions[currentQuizIndex];
                    questionLabel.Text = q.Question;
                    for (int i = 0; i < q.Options.Length; i++)
                    {
                        RadioButton rb = new RadioButton();
                        rb.Text = q.Options[i];
                        rb.Tag = i;
                        answerPanel.Controls.Add(rb);
                    }
                }
            };

            submitAnswerBtn.Click += (s, e) =>
            {
                foreach (Control ctrl in answerPanel.Controls)
                {
                    if (ctrl is RadioButton rb && rb.Checked)
                    {
                        int chosen = (int)rb.Tag;
                        if (chosen == quizQuestions[currentQuizIndex].CorrectIndex)
                        {
                            quizScore++;
                            feedbackLabel.Text = "Correct!";
                        }
                        else
                        {
                            feedbackLabel.Text = "Wrong. Learn more about this topic!";
                        }
                        activityLog.Add("[Quiz] Q" + (currentQuizIndex + 1) + ": " + (chosen == quizQuestions[currentQuizIndex].CorrectIndex ? "Correct" : "Wrong"));
                        currentQuizIndex++;
                        if (currentQuizIndex < quizQuestions.Count)
                        {
                            LoadQuizQuestion();
                        }
                        else
                        {
                            MessageBox.Show("Quiz complete! Your score: " + quizScore + "/" + quizQuestions.Count);
                            currentQuizIndex = 0;
                            quizScore = 0;
                            LoadQuizQuestion();
                        }
                        break;
                    }
                }
            };

            LoadQuizQuestion();
            quizTab.Controls.Add(questionLabel);
            quizTab.Controls.Add(answerPanel);
            quizTab.Controls.Add(submitAnswerBtn);
            quizTab.Controls.Add(feedbackLabel);

            // Log Tab
            ListBox logBox = new ListBox();
            logBox.Dock = DockStyle.Fill;
            Button showLogBtn = new Button();
            showLogBtn.Text = "Show Activity Log";
            showLogBtn.Dock = DockStyle.Top;

            showLogBtn.Click += (s, e) =>
            {
                logBox.Items.Clear();
                IEnumerable<string> latestLogs = activityLog.Skip(Math.Max(0, activityLog.Count - 10));
                foreach (string log in latestLogs)
                    logBox.Items.Add(log);
            };

            logTab.Controls.Add(showLogBtn);
            logTab.Controls.Add(logBox);
        }
    }

    public static class ChatBotLogic
    {
        public static string GetResponse(string input)
        {
            if (input.Contains("password")) return "Use a strong password with numbers and symbols.";
            if (input.Contains("phishing")) return "Be cautious with suspicious emails or links.";
            if (input.Contains("privacy")) return "Always check your privacy settings on social media.";
            if (input.Contains("quiz")) return "Switch to the Quiz tab to test your knowledge!";
            if (input.Contains("task")) return "Switch to the Task tab to manage cybersecurity tasks.";
            if (input.Contains("remind")) return "You can add a reminder in the Task tab.";
            return "I'm not sure I understand that. Can you try asking differently?";
        }
    }

    public class TaskItem
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime Reminder { get; set; }

        public TaskItem(string title, string desc, DateTime reminder)
        {
            Title = title;
            Description = desc;
            Reminder = reminder;
        }

        public override string ToString()
        {
            return $"{Title} - {Description} (Remind: {Reminder.ToShortDateString()})";
        }
    }

    public class QuizQuestion
    {
        public string Question { get; }
        public string[] Options { get; }
        public int CorrectIndex { get; }

        public QuizQuestion(string q, string[] opts, int correct)
        {
            Question = q;
            Options = opts;
            CorrectIndex = correct;
        }
    }
}
